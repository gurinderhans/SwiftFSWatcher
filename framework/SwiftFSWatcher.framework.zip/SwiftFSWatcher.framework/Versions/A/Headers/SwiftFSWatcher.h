//
//  SwiftFSWatcher.h
//  SwiftFSWatcher
//
//  Created by Gurinder Hans on 4/9/16.
//  Copyright © 2016 Gurinder Hans. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SwiftFSWatcher.
FOUNDATION_EXPORT double SwiftFSWatcherVersionNumber;

//! Project version string for SwiftFSWatcher.
FOUNDATION_EXPORT const unsigned char SwiftFSWatcherVersionString[];